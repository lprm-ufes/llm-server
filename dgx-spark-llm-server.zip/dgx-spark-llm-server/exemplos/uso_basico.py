"""
Exemplos de uso da API em Python (cliente oficial da OpenAI).

    pip install openai httpx

Na máquina do servidor:
    export LLM_API_KEY=sk-...
    python uso_basico.py

Remotamente:
    export LLM_API_KEY=sk-...
    export LLM_BASE_URL=https://<SERVIDOR>:8443/v1
    export LLM_CA_CERT=/caminho/fullchain.pem
    python uso_basico.py
"""
import os
import httpx
from openai import OpenAI

BASE_URL = os.getenv("LLM_BASE_URL", "http://127.0.0.1:4000/v1")
CA_CERT  = os.getenv("LLM_CA_CERT")          # obrigatório com https + certificado autoassinado

cliente = OpenAI(
    base_url=BASE_URL,
    api_key=os.environ["LLM_API_KEY"],
    http_client=httpx.Client(verify=CA_CERT or True, timeout=600),
)

# 1. Quais modelos o serviço conhece (só o do motor ativo responde de fato)
print("Modelos:", [m.id for m in cliente.models.list().data])

# 2. Pergunta simples
r = cliente.chat.completions.create(
    model="modelo-principal",
    messages=[
        {"role": "system", "content": "Responda em português, de forma objetiva."},
        {"role": "user", "content": "O que é aprendizado de máquina?"},
    ],
    max_tokens=400,
    temperature=0.3,
)
print("\n--- resposta simples\n", r.choices[0].message.content)
print("tokens:", r.usage.prompt_tokens, "entrada /", r.usage.completion_tokens, "saída")

# 3. Streaming: o texto aparece aos poucos
print("\n--- streaming")
for parte in cliente.chat.completions.create(
        model="modelo-principal", stream=True, max_tokens=200,
        messages=[{"role": "user", "content": "Conte até dez por extenso."}]):
    if parte.choices and parte.choices[0].delta.content:
        print(parte.choices[0].delta.content, end="", flush=True)
print()

# 4. Raciocínio do Qwen3 (desligado por padrão no servidor). Reserve max_tokens de sobra.
r = cliente.chat.completions.create(
    model="modelo-principal", max_tokens=3000,
    messages=[{"role": "user", "content": "Quanto é 17 x 23? Explique o cálculo."}],
    extra_body={"chat_template_kwargs": {"enable_thinking": True}},
)
m = r.choices[0].message
print("\n--- com raciocínio")
print("raciocínio:", (getattr(m, "reasoning_content", None) or "-")[:300], "...")
print("resposta:", m.content)

# 5. Conversa com histórico: reenvie as mensagens anteriores a cada chamada
historico = [{"role": "user", "content": "Meu nome é Ana."}]
r = cliente.chat.completions.create(model="modelo-principal", messages=historico, max_tokens=100)
historico.append({"role": "assistant", "content": r.choices[0].message.content})
historico.append({"role": "user", "content": "Qual é o meu nome?"})
r = cliente.chat.completions.create(model="modelo-principal", messages=historico, max_tokens=100)
print("\n--- histórico\n", r.choices[0].message.content)

# 6. Saída em JSON (útil para extrair dados estruturados)
r = cliente.chat.completions.create(
    model="modelo-principal", max_tokens=300,
    response_format={"type": "json_object"},
    messages=[{"role": "user", "content":
               'Extraia nome e ano em JSON {"nome": str, "ano": int}: '
               '"A Torre Eiffel foi inaugurada por Gustave Eiffel em 1889."'}],
)
print("\n--- JSON\n", r.choices[0].message.content)
