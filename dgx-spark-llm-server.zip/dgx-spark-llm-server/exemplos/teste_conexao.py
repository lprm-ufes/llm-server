"""
Teste rápido da API remota: confere certificado, chave e modelo com uma pergunta curta.

    export LLM_API_KEY=sk-...
    # remoto:
    export LLM_BASE_URL=https://<SERVIDOR>:8443/v1
    export LLM_CA_CERT=/caminho/fullchain.pem
    python teste_conexao.py

    LLM_MODEL escolhe o modelo (padrão: modelo-principal).

Requer: pip install openai httpx
"""
import os, sys, httpx
from openai import OpenAI, AuthenticationError, APIConnectionError

BASE_URL = os.getenv("LLM_BASE_URL", "http://127.0.0.1:4000/v1")
CA_CERT  = os.getenv("LLM_CA_CERT")
if BASE_URL.startswith("https://") and not CA_CERT:
    sys.exit("Defina LLM_CA_CERT com o caminho do fullchain.pem do servidor.")

c = OpenAI(base_url=BASE_URL, api_key=os.environ["LLM_API_KEY"],
           http_client=httpx.Client(verify=CA_CERT or True, timeout=120))
try:
    print("Modelos disponíveis:", [m.id for m in c.models.list().data])
    r = c.chat.completions.create(
        model=os.getenv("LLM_MODEL", "modelo-principal"), max_tokens=300,
        messages=[{"role": "user", "content": "Responda em uma frase: o que é uma API?"}])
    print("Resposta:", r.choices[0].message.content)
    print("Tokens:", r.usage.prompt_tokens, "de entrada,", r.usage.completion_tokens, "de saída")
except AuthenticationError:
    sys.exit("Chave inválida ou expirada (401).")
except APIConnectionError as e:
    sys.exit(f"Sem conexão com {BASE_URL}: {e.__cause__ or e}\n"
             "Confira a rede, o endereço e se LLM_CA_CERT aponta para o fullchain.pem certo.")
