"""
Processamento em lote pela API do serviço LLM (local ou remota).

Uso na própria máquina do servidor (sem TLS):
    export LLM_API_KEY=sk-...
    python batch_cliente.py entrada.jsonl saida.jsonl

Uso remoto (pela rede, com TLS):
    export LLM_API_KEY=sk-...
    export LLM_BASE_URL=https://<SERVIDOR>:8443/v1
    export LLM_CA_CERT=/caminho/fullchain.pem     # certificado do servidor (público)
    python batch_cliente.py entrada.jsonl saida.jsonl

entrada.jsonl: uma linha por item, {"id": "...", "prompt": "..."}
saida.jsonl:   {"id": "...", "resposta": "...", "raciocinio": "...", "erro": null}

Retomada: itens concluídos com sucesso são pulados; itens que falharam são tentados de novo
na próxima execução (a nova linha é acrescentada; ao ler os resultados, use a ÚLTIMA linha
de cada id).

Equivalência com o vLLM offline (para reproduzir resultados antigos):
    llm.generate(prompts, ...)  ->  LLM_MODO=completion  (texto cru, sem chat template)
    llm.chat(mensagens, ...)    ->  LLM_MODO=chat        (aplica o chat template; padrão)
    SamplingParams(...)         ->  PARAMS e EXTRA abaixo

Raciocínio (Qwen3, só no modo chat): desligado por padrão no servidor.
    LLM_THINKING=1 liga, LLM_THINKING=0 força desligado. Com ele ligado, aumente max_tokens
    (2000+), senão o raciocínio é cortado e aparece misturado na resposta.

Limites do servidor: cada chave pode ter limite de requisições por minuto, e cada IP é
limitado a 20 req/s. Respostas 429 (limite atingido) são esperadas e tratadas com novas
tentativas; se forem frequentes, reduza LLM_CONCORRENCIA ou peça uma chave sem limite.

Requer: pip install openai httpx
Variáveis:
    LLM_API_KEY       obrigatória
    LLM_BASE_URL      padrão: http://127.0.0.1:4000/v1 (local); remoto: https://<SERVIDOR>:8443/v1
    LLM_CA_CERT       caminho do fullchain.pem (obrigatório com https e certificado autoassinado)
    LLM_MODEL         padrão: modelo-principal
    LLM_MODO          chat | completion (padrão: chat)
    LLM_THINKING      1 | 0 (opcional)
    LLM_CONCORRENCIA  requisições simultâneas (padrão: 16)
"""
import asyncio, json, os, random, sys
import httpx
from openai import (AsyncOpenAI, APIConnectionError, RateLimitError,
                    InternalServerError, AuthenticationError)

BASE_URL     = os.getenv("LLM_BASE_URL", "http://127.0.0.1:4000/v1")
MODELO       = os.getenv("LLM_MODEL", "modelo-principal")
MODO         = os.getenv("LLM_MODO", "chat")
THINKING     = os.getenv("LLM_THINKING")              # None = padrão do servidor
CONCORRENCIA = int(os.getenv("LLM_CONCORRENCIA", "16"))
CA_CERT      = os.getenv("LLM_CA_CERT")
TENTATIVAS   = 8

# Equivalente ao SamplingParams. Parâmetros próprios do vLLM (top_k, min_p,
# repetition_penalty, seed...) vão em EXTRA.
PARAMS = dict(temperature=0, max_tokens=512)
EXTRA  = {}

# Erros temporários: vale tentar de novo. Os demais (400 prompt longo demais,
# 404 modelo inexistente...) falham na hora.
TEMPORARIOS = (APIConnectionError, RateLimitError, InternalServerError)


def criar_cliente():
    if BASE_URL.startswith("https://") and not CA_CERT:
        sys.exit("Defina LLM_CA_CERT com o caminho do fullchain.pem do servidor.\n"
                 "(Não desative a verificação TLS: a chave de API trafega nessa conexão.)")
    http = httpx.AsyncClient(verify=CA_CERT if CA_CERT else True,
                             timeout=httpx.Timeout(900, connect=15),
                             limits=httpx.Limits(max_connections=CONCORRENCIA))
    # max_retries=0: as novas tentativas ficam só no laço de processar().
    return AsyncOpenAI(base_url=BASE_URL, api_key=os.environ["LLM_API_KEY"],
                       http_client=http, max_retries=0)


async def chamar(cliente, prompt):
    if MODO == "completion":
        r = await cliente.completions.create(model=MODELO, prompt=prompt,
                                             extra_body=EXTRA, **PARAMS)
        return r.choices[0].text, None
    extra = dict(EXTRA)
    if THINKING is not None:
        extra["chat_template_kwargs"] = {"enable_thinking": THINKING == "1"}
    r = await cliente.chat.completions.create(
        model=MODELO, messages=[{"role": "user", "content": prompt}],
        extra_body=extra, **PARAMS)
    m = r.choices[0].message
    return m.content, getattr(m, "reasoning_content", None)


def espera(tentativa, erro):
    # Respeita o Retry-After do servidor quando houver; senão, espera exponencial com
    # variação aleatória (evita que todas as tarefas voltem ao mesmo tempo).
    resp = getattr(erro, "response", None)
    try:
        return float(resp.headers.get("retry-after"))
    except (AttributeError, TypeError, ValueError):
        return min(60, 2 ** tentativa) + random.uniform(0, 1)


async def processar(cliente, item, sem, saida, lock):
    async with sem:
        res = None
        for tentativa in range(TENTATIVAS):
            try:
                resp, rac = await chamar(cliente, item["prompt"])
                res = {"id": item["id"], "resposta": resp, "raciocinio": rac, "erro": None}
                break
            except AuthenticationError:
                raise                      # chave inválida: não adianta continuar
            except TEMPORARIOS as e:
                if tentativa == TENTATIVAS - 1:
                    res = {"id": item["id"], "resposta": None, "raciocinio": None, "erro": repr(e)}
                else:
                    await asyncio.sleep(espera(tentativa, e))
            except Exception as e:         # erro não temporário ou inesperado
                res = {"id": item.get("id"), "resposta": None, "raciocinio": None, "erro": repr(e)}
                break
        async with lock:
            saida.write(json.dumps(res, ensure_ascii=False) + "\n")
            saida.flush()
        return res["erro"] is None


async def main(arq_in, arq_out):
    feitos = set()
    if os.path.exists(arq_out):
        with open(arq_out) as f:
            for l in f:
                if l.strip():
                    r = json.loads(l)
                    (feitos.add if r.get("erro") is None else feitos.discard)(r["id"])
    with open(arq_in) as f:
        itens = [json.loads(l) for l in f if l.strip()]
    pendentes = [i for i in itens if i["id"] not in feitos]
    print(f"{BASE_URL} | modo={MODO} thinking={THINKING or 'padrão do servidor'} | "
          f"{len(itens)} itens, {len(feitos)} já feitos, {len(pendentes)} pendentes")
    if not pendentes:
        return

    cliente = criar_cliente()
    sem, lock, falhas = asyncio.Semaphore(CONCORRENCIA), asyncio.Lock(), 0
    try:
        with open(arq_out, "a") as saida:
            tarefas = [asyncio.create_task(processar(cliente, i, sem, saida, lock))
                       for i in pendentes]
            for n, t in enumerate(asyncio.as_completed(tarefas), 1):
                try:
                    falhas += not await t
                except AuthenticationError:
                    for x in tarefas: x.cancel()
                    sys.exit("Chave de API inválida ou expirada (401). Fale com o administrador.")
                if n % 100 == 0 or n == len(tarefas):
                    print(f"{n}/{len(tarefas)}  (falhas: {falhas})")
    finally:
        await cliente.close()
    if falhas:
        print(f"{falhas} itens falharam; rode o mesmo comando de novo para tentar só esses.")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit("uso: python batch_cliente.py entrada.jsonl saida.jsonl")
    asyncio.run(main(sys.argv[1], sys.argv[2]))
