# Carrega o .env sem executá-lo como shell: aceita valores com espaços, com ou sem aspas,
# e arquivos editados no Windows (CRLF). Uso: source scripts/_env.sh; carregar_env
carregar_env() {
  local arq=${1:-.env} linha k v
  [ -f "$arq" ] || { echo "falta $arq (cp .env.example .env)" >&2; return 1; }
  while IFS= read -r linha || [ -n "$linha" ]; do
    linha=${linha%$'\r'}
    [[ $linha =~ ^[[:space:]]*([A-Za-z_][A-Za-z0-9_]*)=(.*)$ ]] || continue
    k=${BASH_REMATCH[1]}; v=${BASH_REMATCH[2]}
    if [[ $v =~ ^\"(.*)\"[[:space:]]*$ || $v =~ ^\'(.*)\'[[:space:]]*$ ]]; then v=${BASH_REMATCH[1]}; fi
    export "$k=$v"
  done < "$arq"
}
