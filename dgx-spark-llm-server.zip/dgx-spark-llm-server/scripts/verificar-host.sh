#!/usr/bin/env bash
# Verificações antes de subir o serviço. Não precisa de sudo.
ok()   { printf "  \e[32m[ok]\e[0m %s\n" "$*"; }
warn() { printf "  \e[33m[!!]\e[0m %s\n" "$*"; }
fail() { printf "  \e[31m[xx]\e[0m %s\n" "$*"; FAILED=1; }
FAILED=0
cd "$(dirname "$0")/.."
source scripts/_env.sh

echo "== Usuário e Docker"
id -nG | grep -qw docker && ok "usuário no grupo docker" || fail "usuário fora do grupo docker (peça ao admin: sudo usermod -aG docker $USER)"
docker info >/dev/null 2>&1 && ok "daemon Docker acessível" || fail "não consegui falar com o Docker"
docker compose version >/dev/null 2>&1 && ok "docker compose disponível" || fail "falta o plugin docker-compose-plugin (precisa de sudo)"

echo "== GPU"
nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | grep -q GB10 && ok "GB10 visível no host" || fail "GPU GB10 não encontrada"
OUTROS=$(nvidia-smi --query-compute-apps=pid,process_name --format=csv,noheader 2>/dev/null)
if [ -n "$OUTROS" ]; then
  warn "há processos usando a GPU:"; echo "$OUTROS" | sed 's/^/       /'
  for p in $(echo "$OUTROS" | cut -d, -f1); do
    printf "       pid %s -> usuário %s\n" "$p" "$(ps -o user:30= -p "$p" 2>/dev/null)"
  done
  warn "com memória unificada eles disputam os 128 GB com o vLLM; combine antes de subir"
else
  ok "nenhum outro processo na GPU"
fi

echo "== Memória"
free -h | sed 's/^/       /'
DISP=$(free -g | awk '/^Mem:/ {print $7}')
[ "${DISP:-0}" -ge 100 ] && ok "${DISP} GB disponíveis" || warn "só ${DISP} GB disponíveis; reduza GPU_MEM_UTIL ou espere liberar"

echo "== Disco"
LIVRE=$(df -BG --output=avail "$HOME" | tail -1 | tr -dc 0-9)
[ "${LIVRE:-0}" -ge 300 ] && ok "${LIVRE} GB livres" || warn "só ${LIVRE} GB livres"

echo "== Portas"
for p in 80 443 4000 8443; do
  ss -ltn "( sport = :$p )" | grep -q LISTEN && fail "porta $p já em uso" || ok "porta $p livre"
done
EXPOSTAS=$(ss -ltnH | awk '{print $4}' | grep -E '^(0\.0\.0\.0|\[::\]|\*):' | grep -vE ':(22|111)$')
[ -n "$EXPOSTAS" ] && { warn "portas abertas para a rede (não são deste serviço; vale saber o que são):"; echo "$EXPOSTAS" | sed 's/^/       /'; }

echo "== Rede"
if [ -f .env ]; then
  carregar_env
  for SN in "$DOCKER_SUBNET_BACKEND" "$DOCKER_SUBNET_FRONTEND"; do
    PFX=$(echo "$SN" | cut -d. -f1-2)
    ip -4 route | grep -q "^$PFX\." && warn "sub-rede $SN parece coincidir com uma rota do host; escolha outra" || ok "sub-rede $SN sem conflito com as rotas do host"
  done
fi

echo "== Arquivos"
[ -f .env ] && ok ".env existe" || fail "falta .env (cp .env.example .env)"
if [ -f .env ]; then
  grep -q $'\r' .env && warn ".env com fim de linha do Windows (rode scripts/gerar-segredos.sh para corrigir)"
  for V in VLLM_API_KEY LITELLM_MASTER_KEY LITELLM_SALT_KEY POSTGRES_PASSWORD WEBUI_SECRET_KEY; do
    VAL=${!V:-}
    if [ ${#VAL} -lt 20 ] || [[ $VAL == *troque* ]]; then fail "segredo $V vazio ou de exemplo (rode scripts/gerar-segredos.sh)"; fi
  done
  [ -d "${HF_CACHE_DIR:-/nao-definido}" ] && ok "HF_CACHE_DIR existe ($HF_CACHE_DIR)" || fail "HF_CACHE_DIR não existe: ${HF_CACHE_DIR:-não definido} (mkdir -p ...)"
fi
[ -f nginx/certs/fullchain.pem ] && [ -f nginx/certs/privkey.pem ] && ok "certificados presentes" || warn "sem certificados em nginx/certs (o nginx não sobe sem eles)"

echo
[ $FAILED -eq 0 ] && echo "Pronto para seguir." || echo "Resolva os itens [xx] antes de continuar."
exit $FAILED
