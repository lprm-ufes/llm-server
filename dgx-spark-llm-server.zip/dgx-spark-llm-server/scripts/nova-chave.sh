#!/usr/bin/env bash
# Cria uma chave de API para um usuário. Roda na própria Spark (usa 127.0.0.1:4000).
# Uso: scripts/nova-chave.sh <apelido> [rpm] [validade]
#   ex.: scripts/nova-chave.sh usuario-batch 0 365d   (rpm 0 = sem limite)
#        scripts/nova-chave.sh aluno-fulano 30 90d
set -euo pipefail
ALIAS=${1:?informe um apelido, ex.: aluno-fulano}
RPM=${2:-30}
DUR=${3:-90d}
cd "$(dirname "$0")/.."
source scripts/_env.sh; carregar_env
# Sem lista de modelos: a chave vale para todos (modelo-principal e modelo-secundario).
BODY=$(printf '{"key_alias":"%s","duration":"%s"%s}' \
  "$ALIAS" "$DUR" "$([ "$RPM" != 0 ] && echo ",\"rpm_limit\":$RPM")")
curl -fsS http://127.0.0.1:4000/key/generate \
  -H "Authorization: Bearer $LITELLM_MASTER_KEY" -H "Content-Type: application/json" \
  -d "$BODY" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d['key'])"
