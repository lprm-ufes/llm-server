#!/usr/bin/env bash
# Baixa um modelo GGUF para HF_CACHE_DIR/gguf e grava GGUF_FILE no .env.
#
# Uso:
#   scripts/baixar-gguf.sh <repo-hf> --listar          mostra os .gguf do repositório e tamanhos
#   scripts/baixar-gguf.sh <repo-hf> <quantização>     baixa, ex.: Q8_0, Q6_K, Q4_K_P
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/_env.sh; carregar_env

REPO=${1:?uso: scripts/baixar-gguf.sh <repo-hf> --listar | <quantização>}
QUANT=${2:?informe --listar ou a quantização (ex.: Q8_0)}
TOKEN=${HF_TOKEN:-}; [[ "$TOKEN" == hf_xxx ]] && TOKEN=""
AUTH=(); [ -n "$TOKEN" ] && AUTH=(-H "Authorization: Bearer $TOKEN")

if [ "$QUANT" = "--listar" ]; then
  curl -fsS "${AUTH[@]}" "https://huggingface.co/api/models/$REPO?blobs=true" > /tmp/gguf-lista.json
  python3 - /tmp/gguf-lista.json << 'PY'
import json, sys
fs = [s for s in json.load(open(sys.argv[1]))["siblings"] if s["rfilename"].endswith(".gguf")]
for s in sorted(fs, key=lambda s: s.get("size") or 0):
    tag = "  (visão, não precisa)" if "mmproj" in s["rfilename"].lower() else ""
    print("%7.1f GB  %s%s" % ((s.get("size") or 0) / 1e9, s["rfilename"], tag))
PY
  echo
  echo "Com a Spark dedicada a um motor por vez, cabe até ~90 GB de pesos."
  exit 0
fi

SLUG=$(echo "$REPO" | tr '/' '_')
DEST="$HF_CACHE_DIR/gguf/$SLUG"
mkdir -p "$DEST"
TOKEN_ENV=$TOKEN
echo "== Baixando arquivos *$QUANT*.gguf de $REPO para $DEST"
docker run --rm --user "$(id -u):$(id -g)" \
  -e HOME=/tmp -e HF_HOME=/tmp/hf -e HF_TOKEN="$TOKEN_ENV" \
  -v "$DEST:/out" --entrypoint bash "$VLLM_IMAGE" -c '
    if command -v hf >/dev/null 2>&1; then CLI="hf download"; else CLI="huggingface-cli download"; fi
    $CLI "$1" --include "*$2*.gguf" --exclude "*mmproj*" --local-dir /out' _ "$REPO" "$QUANT"

# Arquivo principal: o único .gguf da quantização, ou a parte 00001 se vier dividido.
LISTA=$(cd "$DEST" && ls -1 | grep -i -- "$QUANT" | grep -iv mmproj | grep -E '\.gguf$' || true)
ARQ=$(echo "$LISTA" | grep -E -- '-0*1-of-' | head -1 || true)
[ -n "$ARQ" ] || ARQ=$(echo "$LISTA" | head -1)
[ -n "$ARQ" ] || { echo "Nenhum .gguf com '$QUANT' encontrado. Veja as opções com --listar."; exit 1; }

if grep -qE '^GGUF_FILE=' .env; then sed -i "s|^GGUF_FILE=.*|GGUF_FILE=\"$SLUG/$ARQ\"|" .env
else echo "GGUF_FILE=\"$SLUG/$ARQ\"" >> .env; fi
echo "== Pronto: GGUF_FILE=$SLUG/$ARQ ($(du -sh "$DEST/$ARQ" | cut -f1))"
