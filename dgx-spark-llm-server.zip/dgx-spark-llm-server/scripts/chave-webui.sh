#!/usr/bin/env bash
# Cria (ou troca) a chave que o Open WebUI usa para falar com o LiteLLM.
#
# Uso: scripts/chave-webui.sh
#
# Na PRIMEIRA instalação, o Open WebUI lê a chave do .env e funciona sozinho.
# Depois disso ele guarda a conexão no próprio banco e IGNORA o .env: ao trocar a chave,
# é preciso colá-la também na interface (o script mostra onde).
set -euo pipefail
cd "$(dirname "$0")/.."

scripts/revogar-chave.sh open-webui >/dev/null 2>&1 || true
K=$(scripts/nova-chave.sh open-webui 0 3650d)
sed -i "s|^WEBUI_LITELLM_KEY=.*|WEBUI_LITELLM_KEY=$K|" .env

if docker volume ls -q | grep -q '_webui-data$'; then
  cat << MSG
Chave nova gravada no .env. O Open WebUI já foi inicializado, então cole a chave na interface:
  Painel do Administrador > Configurações > Conexões > API OpenAI
  endereço: http://litellm:4000/v1
  chave:    $K
(Não compartilhe essa chave: ela não tem limite de uso.)
MSG
else
  echo "Chave gravada no .env. Suba o Open WebUI com: docker compose up -d open-webui"
fi
