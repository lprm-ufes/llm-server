#!/usr/bin/env bash
# Preenche no .env os segredos vazios ou com valor de exemplo ("troque..."). Não mexe em
# valores já definidos. Também converte o .env para fim de linha Unix, se necessário.
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f .env ] || cp .env.example .env
sed -i 's/\r$//' .env
for VAR in VLLM_API_KEY LITELLM_MASTER_KEY LITELLM_SALT_KEY POSTGRES_PASSWORD WEBUI_SECRET_KEY; do
  if ! grep -qE "^${VAR}=" .env; then echo "${VAR}=" >> .env; fi
  if grep -qE "^${VAR}=(\"\"|''|(sk-)?troque.*)?$" .env; then
    VAL=$(openssl rand -hex 32)
    case $VAR in LITELLM_*) VAL="sk-$VAL";; esac
    sed -i "s|^${VAR}=.*|${VAR}=${VAL}|" .env
    echo "  gerado:       $VAR"
  else
    echo "  já definido:  $VAR (mantido)"
  fi
done
chmod 600 .env
echo "Atenção: LITELLM_SALT_KEY não pode mudar depois que houver chaves criadas."
