#!/usr/bin/env bash
# Baixa os pesos de um modelo para o HF_CACHE_DIR.
# O vLLM roda numa rede interna SEM acesso à internet (por segurança) e em modo offline,
# então todo modelo precisa ser baixado antes por este script.
#
# Uso: scripts/baixar-modelo.sh [repo-hf]     (sem argumento: usa MODEL do .env)
# Pode interromper e rodar de novo: o download continua de onde parou.
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/_env.sh; carregar_env

MODELO=${1:-$MODEL}
mkdir -p "$HF_CACHE_DIR"
TOKEN=${HF_TOKEN:-}; [[ "$TOKEN" == hf_xxx ]] && TOKEN=""

echo "== Baixando $MODELO para $HF_CACHE_DIR"
# Usa a própria imagem do vLLM (já tem o cliente do Hugging Face), na rede padrão do Docker,
# sem GPU e com o seu usuário, para os arquivos ficarem com o dono certo.
docker run --rm \
  --user "$(id -u):$(id -g)" \
  -e HOME=/tmp -e HF_HOME=/hf -e HF_TOKEN="$TOKEN" \
  -v "$HF_CACHE_DIR:/hf" \
  --entrypoint bash "$VLLM_IMAGE" -c '
    if command -v hf >/dev/null 2>&1; then hf download "$1"
    else huggingface-cli download "$1"; fi' _ "$MODELO"
echo "== Concluído. Tamanho do cache: $(du -sh "$HF_CACHE_DIR" | cut -f1)"
