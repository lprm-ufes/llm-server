#!/usr/bin/env bash
# Revoga uma ou mais chaves de API pelo apelido (key_alias). Roda na máquina do servidor.
# Uso: scripts/revogar-chave.sh <apelido> [outro-apelido ...]
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/_env.sh; carregar_env
[ $# -ge 1 ] || { echo "uso: scripts/revogar-chave.sh <apelido> [...]"; exit 1; }
JSON=$(python3 -c 'import json,sys; print(json.dumps({"key_aliases": sys.argv[1:]}))' "$@")
curl -fsS http://127.0.0.1:4000/key/delete \
  -H "Authorization: Bearer $LITELLM_MASTER_KEY" -H "Content-Type: application/json" -d "$JSON"
echo
