#!/usr/bin/env bash
# Escolhe qual motor de inferência fica ativo (só um por vez, para usar a memória toda).
#
# Uso:
#   scripts/motor.sh qwen32b       vLLM com o Qwen3-32B     -> modelo "modelo-principal"
#   scripts/motor.sh uncensored    llama.cpp com o GGUF     -> modelo "modelo-secundario"
#   scripts/motor.sh status        mostra qual está ativo
#
# LiteLLM, Open WebUI, nginx e as chaves não são reiniciados. Durante a troca o serviço
# fica sem modelo por alguns minutos; avise os usuários.
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/_env.sh; carregar_env

status() {
  for c in vllm llamacpp; do
    st=$(docker inspect -f '{{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{end}}' "$c" 2>/dev/null || echo "parado")
    printf "  %-9s %s\n" "$c" "$st"
  done
}

case "${1:-}" in
  qwen32b)    PERFIL=qwen32b;    SVC=vllm;     OUTRO=llamacpp; NOME=modelo-principal ;;
  uncensored) PERFIL=uncensored; SVC=llamacpp; OUTRO=vllm;     NOME=modelo-secundario ;;
  status)     echo "Motor configurado: ${COMPOSE_PROFILES:-?}"; status; exit 0 ;;
  *) echo "uso: scripts/motor.sh qwen32b | uncensored | status"; exit 1 ;;
esac

if [ "$PERFIL" = uncensored ]; then
  [ -n "${GGUF_FILE:-}" ] && [ -f "$HF_CACHE_DIR/gguf/$GGUF_FILE" ] || {
    echo "Modelo GGUF não encontrado. Baixe antes com scripts/baixar-gguf.sh"; exit 1; }
  if ! docker image inspect "llamacpp-gb10:$LLAMACPP_TAG" >/dev/null 2>&1; then
    echo "== Compilando o llama.cpp para a GB10 (só na primeira vez; 20-30 min)"
    docker compose --profile uncensored build llamacpp
  fi
fi

echo "== Parando $OUTRO (se estiver rodando)"
docker rm -f "$OUTRO" >/dev/null 2>&1 || true
sleep 3

if grep -qE '^COMPOSE_PROFILES=' .env; then sed -i "s|^COMPOSE_PROFILES=.*|COMPOSE_PROFILES=$PERFIL|" .env
else echo "COMPOSE_PROFILES=$PERFIL" >> .env; fi

echo "== Subindo $SVC"
docker compose --profile "$PERFIL" up -d "$SVC"
printf "  carregando o modelo"
for i in $(seq 1 120); do
  ST=$(docker inspect -f '{{.State.Health.Status}}' "$SVC" 2>/dev/null || echo "?")
  if [ "$ST" = healthy ]; then echo; echo "Pronto: motor '$PERFIL' ativo, use o modelo '$NOME'."; exit 0; fi
  if [ "$(docker inspect -f '{{.State.Running}}' "$SVC" 2>/dev/null)" != true ]; then
    echo; echo "$SVC parou. Últimas linhas do log:"; docker logs --tail 30 "$SVC"; exit 1
  fi
  printf "."; sleep 10
done
echo; echo "Ainda carregando após 20 min; acompanhe com: docker logs -f $SVC"
