#!/usr/bin/env bash
# Certificado autoassinado para o IP (ou nome) da Spark, enquanto não há um certificado
# institucional. Navegadores mostram um aviso; clientes da API precisam confiar no
# arquivo nginx/certs/fullchain.pem (ver README, seção 6).
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/_env.sh; carregar_env
CN=${SERVER_NAME:?defina SERVER_NAME no .env}
if [[ $CN =~ ^[0-9.]+$ ]]; then SAN="IP:$CN"; else SAN="DNS:$CN"; fi
mkdir -p nginx/certs
openssl req -x509 -newkey rsa:3072 -sha256 -days 825 -nodes \
  -keyout nginx/certs/privkey.pem -out nginx/certs/fullchain.pem \
  -subj "/CN=$CN/O=LLM Server" -addext "subjectAltName=$SAN,IP:127.0.0.1"
chmod 600 nginx/certs/privkey.pem
echo "Certificado gerado para $SAN (válido por 825 dias)."
