#!/usr/bin/env bash
# Troca o modelo servido sem editar nada à mão.
#
# Uso: scripts/trocar-modelo.sh <repo-hf> [contexto] [--sem-reiniciar]
#   ex.: scripts/trocar-modelo.sh Qwen/Qwen3-32B
#        scripts/trocar-modelo.sh Qwen/Qwen3-32B-FP8 16384
#        scripts/trocar-modelo.sh meta-llama/Llama-3.1-8B-Instruct
#
# O que faz:
#  1. consulta o Hugging Face: tamanho dos pesos e contexto máximo do modelo
#  2. avisa se os pesos não cabem na memória reservada (GPU_MEM_UTIL x 128 GB)
#  3. escolhe o --reasoning-parser pela família do modelo (ou nenhum)
#  4. grava MODEL, MODEL_MAX_LEN e VLLM_EXTRA_ARGS no .env
#  5. baixa os pesos (o vLLM não tem acesso à internet)
#  6. reinicia só o vLLM e espera ficar pronto
# O nome que os clientes usam (MODEL_ALIAS, "modelo-principal") não muda: LiteLLM, Open WebUI
# e scripts dos usuários continuam funcionando sem alteração.
set -euo pipefail
cd "$(dirname "$0")/.."

MODELO=${1:?uso: scripts/trocar-modelo.sh <repo-hf> [contexto] [--sem-reiniciar]}
CTX_PEDIDO=${2:-}
[[ "$CTX_PEDIDO" == --* ]] && CTX_PEDIDO=""
REINICIAR=1; [[ " $* " == *" --sem-reiniciar "* ]] && REINICIAR=0
CTX_PADRAO_MAX=32768     # teto quando nenhum contexto é pedido (KV cache é caro)
MEM_TOTAL_GB=128

source scripts/_env.sh; carregar_env
AUTH=(); [ -n "${HF_TOKEN:-}" ] && [ "$HF_TOKEN" != "hf_xxx" ] && AUTH=(-H "Authorization: Bearer $HF_TOKEN")

echo "== Consultando $MODELO no Hugging Face"
INFO=$(curl -fsS "${AUTH[@]}" "https://huggingface.co/api/models/$MODELO?blobs=true") \
  || { echo "não encontrei o modelo (nome errado, ou repositório restrito: aceite a licença e defina HF_TOKEN)"; exit 1; }
CFG=$(curl -fsSL "${AUTH[@]}" "https://huggingface.co/$MODELO/resolve/main/config.json" || echo '{}')

read -r PESOS_GB CTX_MODELO < <(python3 - "$INFO" "$CFG" << 'PY'
import json, sys
info, cfg = json.loads(sys.argv[1]), json.loads(sys.argv[2])
tam = sum(s.get("size") or 0 for s in info.get("siblings", [])
          if s["rfilename"].endswith((".safetensors", ".bin")) and "/" not in s["rfilename"])
c = cfg.get("text_config", cfg)
ctx = c.get("max_position_embeddings") or 0
print(round(tam / 1e9, 1), ctx)
PY
)

if [ -n "$CTX_PEDIDO" ]; then CTX=$CTX_PEDIDO
elif [ "$CTX_MODELO" -gt 0 ] && [ "$CTX_MODELO" -lt "$CTX_PADRAO_MAX" ]; then CTX=$CTX_MODELO
else CTX=$CTX_PADRAO_MAX; fi
[ "$CTX_MODELO" -gt 0 ] && [ "$CTX" -gt "$CTX_MODELO" ] && \
  echo "  aviso: contexto $CTX acima do nativo ($CTX_MODELO); o vLLM pode recusar sem rope scaling"

RESERVA=$(python3 -c "print(round(${GPU_MEM_UTIL:-0.8} * $MEM_TOTAL_GB, 1))")
echo "  pesos:            ${PESOS_GB} GB"
echo "  contexto nativo:  ${CTX_MODELO:-?}  -> usando $CTX"
echo "  memória do vLLM:  ${RESERVA} GB (GPU_MEM_UTIL=${GPU_MEM_UTIL})"
python3 - "$PESOS_GB" "$RESERVA" << 'PY' || { echo "Abortado: não cabe. Use uma versão quantizada (FP8/NVFP4) ou aumente GPU_MEM_UTIL."; exit 1; }
import sys
p, r = map(float, sys.argv[1:])
livre = r - p
if p == 0: print("  aviso: não consegui medir os pesos; confira manualmente"); sys.exit(0)
if livre < 5:  print(f"  NÃO CABE: sobram {livre:.1f} GB para KV cache"); sys.exit(1)
if livre < 15: print(f"  aviso: só {livre:.1f} GB para KV cache; reduza o contexto ou a concorrência")
else:          print(f"  ok: {livre:.1f} GB para KV cache")
PY

NOME=$(echo "$MODELO" | tr 'A-Z' 'a-z')
case "$NOME" in
  *qwen3*)                       PARSER="--reasoning-parser qwen3 --enable-auto-tool-choice --tool-call-parser hermes" ;;
  *deepseek-r1*|*qwq*)           PARSER="--reasoning-parser deepseek_r1" ;;
  *)                             PARSER="" ;;
esac
echo "  reasoning parser: ${PARSER:-nenhum}"

set_env() { # set_env VAR valor  (cria a linha se não existir)
  local linha="$1=\"$2\""
  if grep -qE "^$1=" .env; then sed -i "s|^$1=.*|$linha|" .env; else echo "$linha" >> .env; fi
}
cp .env .env.bak
set_env MODEL "$MODELO"
set_env MODEL_MAX_LEN "$CTX"
set_env VLLM_EXTRA_ARGS "$PARSER"
# enable_thinking só faz sentido para o Qwen3; para outros modelos, padrões vazios.
if [[ "$NOME" != *qwen3* ]]; then
  if grep -qE "^CHAT_TEMPLATE_DEFAULTS=" .env; then sed -i 's|^CHAT_TEMPLATE_DEFAULTS=.*|CHAT_TEMPLATE_DEFAULTS={}|' .env
  else echo 'CHAT_TEMPLATE_DEFAULTS={}' >> .env; fi
elif ! grep -qE "^CHAT_TEMPLATE_DEFAULTS=" .env; then
  echo 'CHAT_TEMPLATE_DEFAULTS={"enable_thinking":false}' >> .env
fi
echo "== .env atualizado (cópia anterior em .env.bak)"

scripts/baixar-modelo.sh "$MODELO"

[ $REINICIAR -eq 0 ] && { echo "Sem reiniciar. Aplique com: docker compose up -d vllm"; exit 0; }

echo "== Reiniciando o vLLM (o serviço fica fora do ar até o modelo carregar)"
docker compose up -d vllm
printf "  aguardando"
for i in $(seq 1 240); do
  ST=$(docker inspect -f '{{.State.Health.Status}}' vllm 2>/dev/null || echo "?")
  [ "$ST" = healthy ] && { echo; echo "Pronto: $MODELO servido como '${MODEL_ALIAS}'."; exit 0; }
  if [ "$(docker inspect -f '{{.State.Running}}' vllm)" != true ]; then
    echo; echo "o vLLM parou. Últimas linhas do log:"; docker compose logs --tail 30 vllm
    echo "Para voltar ao modelo anterior: cp .env.bak .env && docker compose up -d vllm"; exit 1
  fi
  printf "."; sleep 10
done
echo; echo "Ainda carregando após 40 min; acompanhe com: docker compose logs -f vllm"
